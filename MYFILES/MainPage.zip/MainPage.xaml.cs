﻿using Plugin.BLE;
using Plugin.BLE.Abstractions.Contracts;
using Plugin.BLE.Abstractions.EventArgs;
using Plugin.BLE.Abstractions.Exceptions;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using Microcharts;
using SkiaSharp;

namespace MauiApp1
{
    public partial class MainPage : ContentPage
    {
        // --- BLE 관련 핵심 객체 ---
        private readonly IAdapter _adapter;
        private IDevice? _connectedDevice;
        private IService? _uartService;
        private ICharacteristic? _txCharacteristic; // 데이터 전송용
        private ICharacteristic? _rxCharacteristic; // 데이터 수신용

        // --- UI 바인딩용 장치 리스트 ---
        private ObservableCollection<IDevice> _foundDevices;

        // --- BLE UART 서비스 UUID (Nordic UART Service) ---
        private const string UartServiceUuid = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E";
        private const string TxCharacteristicUuid = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"; // TX (앱 -> 장치)
        private const string RxCharacteristicUuid = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"; // RX (장치 -> 앱)

        // --- 타겟 장치 이름 ---
        private const string TargetDeviceName = "NU40";
        
        // ADC 데이터 저장 (타임스탬프, 값)
        private readonly List<(double timestamp, double value)> _adcValues;
        private double _lastTimestamp = 0.0;

        // --- 차트 관련 변수들 ---
        private List<ChartEntry> _chartEntries;
        private bool _isLineChart = true; // true: 라인차트, false: 막대차트
        private const int MaxDataPoints = 100; // 최대 데이터 포인트 수 (라인차트용)

        public MainPage()
        {
            InitializeComponent();

            // --- BLE 객체 초기화 ---
            _adapter = CrossBluetoothLE.Current.Adapter;
            _foundDevices = new ObservableCollection<IDevice>();
            DeviceListView.ItemsSource = _foundDevices;
            _adcValues = new List<(double timestamp, double value)>();
            
            // --- 차트 초기화 ---
            _chartEntries = new List<ChartEntry>();
            InitializeChart();

            // --- BLE 이벤트 핸들러 연결 ---
            _adapter.DeviceDiscovered += OnDeviceDiscovered;
            _adapter.DeviceConnectionLost += OnDeviceConnectionLost;
        }

        // --- 권한 체크 메서드 ---
        private async Task<bool> CheckAndRequestPermissions()
        {
#if ANDROID
            // BLUETOOTH_SCAN 권한 요청 (Android 12+에서만 필요)
            var scanPermission = await Permissions.CheckStatusAsync<BluetoothScanPermission>();
            if (scanPermission != PermissionStatus.Granted)
            {
                scanPermission = await Permissions.RequestAsync<BluetoothScanPermission>();
            }

            // BLUETOOTH_CONNECT 권한 요청 (Android 12+에서만 필요)
            var connectPermission = await Permissions.CheckStatusAsync<BluetoothConnectPermission>();
            if (connectPermission != PermissionStatus.Granted)
            {
                connectPermission = await Permissions.RequestAsync<BluetoothConnectPermission>();
            }

            // 위치 권한도 필요 (BLE 스캔용)
            var locationPermission = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (locationPermission != PermissionStatus.Granted)
            {
                locationPermission = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            }

            return scanPermission == PermissionStatus.Granted && 
                   connectPermission == PermissionStatus.Granted && 
                   locationPermission == PermissionStatus.Granted;
#else
            await Task.CompletedTask; // async 경고 방지
            return true; // iOS, Windows 등의 경우
#endif
        }

        // --- 스캔 버튼 클릭 이벤트 ---
        private async void OnScanButtonClicked(object sender, EventArgs e)
        {
            bool permissionsGranted = await CheckAndRequestPermissions();
            if (!permissionsGranted)
            {
                await DisplayAlert("권한 오류", "Bluetooth 및 위치 권한이 필요합니다.", "확인");
                return;
            }

            if (_adapter.IsScanning)
            {
                await _adapter.StopScanningForDevicesAsync();
                StatusLabel.Text = "스캔 중지됨";
                ScanButton.Text = "NU40 스캔 시작";
            }
            else
            {
                _foundDevices.Clear();
                StatusLabel.Text = "NU40 스캔 중...";
                ScanButton.Text = "스캔 중지";

                Debug.WriteLine("[BLE] UART 서비스 (UUID: {0})로 스캔 시작...", UartServiceUuid);
                
                // 서비스 UUID 기반 스캔
                await _adapter.StartScanningForDevicesAsync(new[] { Guid.Parse(UartServiceUuid) });
                
                // 10초 후 자동으로 스캔 중지
                _ = Task.Run(async () =>
                {
                    await Task.Delay(10000);
                    if (_adapter.IsScanning)
                    {
                        await _adapter.StopScanningForDevicesAsync();
                        MainThread.BeginInvokeOnMainThread(() =>
                        {
                            StatusLabel.Text = "스캔 완료";
                            ScanButton.Text = "NU40 스캔 시작";
                            Debug.WriteLine("[BLE] 스캔 자동 중지됨");
                        });
                    }
                });
            }
        }

        // --- 장치 발견 시 이벤트 ---
        private void OnDeviceDiscovered(object? sender, DeviceEventArgs e)
        {
            var device = e.Device;
            
            // 모든 발견된 장치를 로그로 출력
            if (device != null)
            {
                Debug.WriteLine($"[BLE] 장치 발견 - 이름: {device.Name ?? "Unknown"}, ID: {device.Id}, RSSI: {device.Rssi}");
            }
            
            // 모든 장치를 리스트에 추가 (이름 필터 제거)
            if (device != null && !_foundDevices.Contains(device))
            {
                MainThread.BeginInvokeOnMainThread(() =>
                {
                    _foundDevices.Add(device);
                    Debug.WriteLine($"[BLE] 리스트에 추가됨 - 이름: {device.Name ?? "Unknown"}");
                });
            }
        }

        // --- ListView에서 장치 선택(연결) 이벤트 ---
        private async void OnDeviceSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null) return;

            var device = e.SelectedItem as IDevice;
            ((ListView)sender).SelectedItem = null;

            try
            {
                StatusLabel.Text = $"{device?.Name}에 연결 중...";
                await _adapter.StopScanningForDevicesAsync();

                await _adapter.ConnectToDeviceAsync(device);
                _connectedDevice = device;
                StatusLabel.Text = $"{device?.Name} 연결 성공!";

                try
                {
                    Debug.WriteLine("[BLE] Requesting MTU update...");
                    // RequestMtuAsync는 협상된 *전체* MTU 크기를 반환합니다.
                    if (_connectedDevice != null)
                    {
                        var newMtu = await _connectedDevice.RequestMtuAsync(128);
                        Debug.WriteLine($"[BLE] MTU update complete. New MTU: {newMtu}");
                    }
                }
                catch (Exception mtuEx)
                {
                    // 일부 OS(오래된 Android)는 명시적 요청을 지원하지 않을 수 있음.
                    Debug.WriteLine($"[BLE] MTU update failed (continuing anyway): {mtuEx.Message}");
                }

                // UART 서비스 찾기
                if (_connectedDevice != null)
                {
                    _uartService = await _connectedDevice.GetServiceAsync(Guid.Parse(UartServiceUuid));
                }
                if (_uartService == null)
                {
                    await DisplayAlert("오류", "UART 서비스를 찾을 수 없습니다.", "확인");
                    return;
                }

                // TX 특성 (앱 -> 장치)
                _txCharacteristic = await _uartService.GetCharacteristicAsync(Guid.Parse(TxCharacteristicUuid));
                if (_txCharacteristic == null)
                {
                    await DisplayAlert("오류", "TX 특성을 찾을 수 없습니다.", "확인");
                    return;
                }

                // RX 특성 (장치 -> 앱)
                _rxCharacteristic = await _uartService.GetCharacteristicAsync(Guid.Parse(RxCharacteristicUuid));
                if (_rxCharacteristic == null)
                {
                    await DisplayAlert("오류", "RX 특성을 찾을 수 없습니다.", "확인");
                    return;
                }

                // RX 특성 구독 시작
                Debug.WriteLine("[BLE] RX characteristic 구독 시작...");
                _rxCharacteristic.ValueUpdated += OnDataReceived;
                
                try
                {
                    await _rxCharacteristic.StartUpdatesAsync();
                    Debug.WriteLine("[BLE] RX characteristic 구독 완료");
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[BLE] RX characteristic 구독 실패: {ex.Message}");
                }

                // UI 업데이트
                ConnectionStatusLabel.Text = "연결됨";
                ConnectionStatusLabel.TextColor = Microsoft.Maui.Graphics.Colors.Green;
                StatusLabel.Text = "데이터 수신 대기 중...";
                
                Debug.WriteLine("[BLE] 모든 설정 완료, 데이터 수신 대기 중...");
            }
            catch (DeviceConnectionException ex)
            {
                StatusLabel.Text = "연결 실패";
                await DisplayAlert("연결 오류", ex.Message, "확인");
            }
            catch (Exception ex)
            {
                StatusLabel.Text = "오류 발생";
                await DisplayAlert("오류", ex.Message, "확인");
            }
        }


        // --- 데이터 수신 이벤트 ---
        private void OnDataReceived(object? sender, CharacteristicUpdatedEventArgs e)
        {
            var bytes = e.Characteristic.Value;

            Debug.WriteLine($"[OnDataReceived] 데이터 수신됨 - Length: {bytes?.Length ?? 0}");

            if (bytes != null && bytes.Length == 40) // 40바이트 패킷 (20 샘플 * 2바이트)
            {
                // int16_t 배열로 변환 (20개 샘플)
                var samples = new short[20];
                for (int i = 0; i < 20; i++)
                {
                    samples[i] = BitConverter.ToInt16(bytes, i * 2);
                }

                Debug.WriteLine($"[ADC] 샘플 0-4: {samples[0]}, {samples[1]}, {samples[2]}, {samples[3]}, {samples[4]}");
                Debug.WriteLine($"[ADC] 샘플 15-19: {samples[15]}, {samples[16]}, {samples[17]}, {samples[18]}, {samples[19]}");
                Debug.WriteLine($"[ADC] 전체 범위: {samples.Min()} ~ {samples.Max()}");

                MainThread.BeginInvokeOnMainThread(() =>
                {
                    // ADC 값 저장 및 차트에 추가
                    const double SampleInterval = 0.01;

                    for (int i = 0; i < 20; i++)
                    {
                        // 타임스탬프를 10ms(0.01초)씩 일정하게 증가
                        _lastTimestamp += SampleInterval;

                        double value = (double)samples[i];
                        _adcValues.Add((_lastTimestamp, value));

                        // 최대 2000개 데이터 포인트 유지 (100Hz * 20초 = 2000개)
                        while (_adcValues.Count > 2000)
                        {
                            _adcValues.RemoveAt(0);
                        }

                        // 차트에 데이터 추가 (Myoware 방식)
                        AddDataToChart(value);
                    }

                    Debug.WriteLine($"[AdcValues] 현재 데이터 개수: {_adcValues.Count}, 마지막 타임스탬프: {_lastTimestamp:F3}s");
                    ResponseLabel.Text = $"수신: {samples.Length}개 샘플, 최신값: {samples[19]}, 전체: {_adcValues.Count}개";
                });
                
                Debug.WriteLine($"[NU40DK] ADC 데이터 수신: {samples.Length}개 샘플, 최신값: {samples[19]}");
            }
            else if (bytes != null)
            {
                Debug.WriteLine($"[OnDataReceived] 잘못된 패킷 크기: {bytes.Length} (예상: 40)");
            }
        }
        
        // --- 차트 초기화 ---
        private void InitializeChart()
        {
            _chartEntries = new List<ChartEntry>();
            UpdateChart();
        }

        // --- 차트에 데이터 추가 (Myoware 방식) ---
        private void AddDataToChart(double value)
        {
            ProcessChartData((float)value);
        }

        // --- 차트 데이터 처리 (공통 로직) ---
        private void ProcessChartData(float clampedValue)
        {
            if (_isLineChart)
            {
                // 라인 차트용: 시계열 데이터 추가
                var entry = new ChartEntry(clampedValue)
                {
                    Color = SKColor.Parse("#3498db"),
                    Label = "",
                    ValueLabel = ""
                };

                _chartEntries.Add(entry);

                // 최대 데이터 포인트 수를 초과하면 오래된 데이터 제거
                if (_chartEntries.Count > MaxDataPoints)
                {
                    _chartEntries.RemoveAt(0);
                }
            }
            else
            {
                // 막대 차트용: 현재 값만 유지 (단일 막대)
                if (_chartEntries.Count > 0)
                {
                    _chartEntries[0] = new ChartEntry(clampedValue)
                    {
                        Color = SKColor.Parse("#e74c3c"),
                        Label = "현재 값",
                        ValueLabel = clampedValue.ToString("F0")
                    };
                }
                else
                {
                    var entry = new ChartEntry(clampedValue)
                    {
                        Color = SKColor.Parse("#e74c3c"),
                        Label = "현재 값",
                        ValueLabel = clampedValue.ToString("F0")
                    };
                    _chartEntries.Add(entry);
                }
            }

            // 차트 업데이트
            UpdateChart();
        }

        // --- 차트 표시 업데이트 ---
        private void UpdateChart()
        {
            Chart chart;
            
            if (_isLineChart)
            {
                // 라인 차트 - Y축 범위 고정
                chart = new LineChart()
                {
                    Entries = _chartEntries,
                    LineMode = LineMode.Straight,
                    LineSize = 3,
                    PointMode = PointMode.None,
                    BackgroundColor = SKColors.Transparent,
                    LabelTextSize = 10,
                    LabelOrientation = Orientation.Horizontal,
                    ValueLabelOrientation = Orientation.Horizontal,
                    MinValue = 0,
                    MaxValue = 4095,
                    AnimationDuration = TimeSpan.Zero,
                    IsAnimated = false
                };
            }
            else
            {
                // 막대 차트 - Y축 범위 고정
                chart = new BarChart()
                {
                    Entries = _chartEntries,
                    BackgroundColor = SKColors.Transparent,
                    LabelTextSize = 12,
                    LabelOrientation = Orientation.Horizontal,
                    ValueLabelOrientation = Orientation.Horizontal,
                    MinValue = 0,
                    MaxValue = 4095,
                    AnimationDuration = TimeSpan.Zero,
                    IsAnimated = false
                };
            }

            DataChart.Chart = chart;
        }

        // --- 차트 타입 토글 ---
        private void ToggleChartType()
        {
            _isLineChart = !_isLineChart;
            
            if (_isLineChart)
            {
                Debug.WriteLine("[Chart] 라인 그래프로 전환");
            }
            else
            {
                Debug.WriteLine("[Chart] 막대 그래프로 전환");
                // 막대 차트로 전환 시 현재 값으로 초기화
                if (_chartEntries.Count > 0)
                {
                    var currentValue = _chartEntries[_chartEntries.Count - 1].Value;
                    _chartEntries.Clear();
                    var entry = new ChartEntry(currentValue)
                    {
                        Color = SKColor.Parse("#e74c3c"),
                        Label = "현재 값",
                        ValueLabel = currentValue.ToString("F0")
                    };
                    _chartEntries.Add(entry);
                }
            }
            
            UpdateChart();
        }

        // --- 차트 타입 토글 버튼 클릭 이벤트 ---
        private void OnChartTypeButtonClicked(object sender, EventArgs e)
        {
            ToggleChartType();
            
            var button = sender as Button;
            if (button != null)
            {
                if (_isLineChart)
                {
                    button.Text = "막대그래프로 전환";
                    button.BackgroundColor = Colors.Green;
                }
                else
                {
                    button.Text = "선그래프로 전환";
                    button.BackgroundColor = Colors.Blue;
                }
            }
        }

        // --- 연결 해제 이벤트 ---
        private void OnDeviceConnectionLost(object? sender, DeviceErrorEventArgs e)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                StatusLabel.Text = "연결 끊어짐";
                ConnectionStatusLabel.Text = "연결되지 않음";
                ConnectionStatusLabel.TextColor = Microsoft.Maui.Graphics.Colors.Red;
                _connectedDevice = null;
                
                if (_rxCharacteristic != null)
                {
                    _rxCharacteristic.ValueUpdated -= OnDataReceived;
                }
            });
        }
    }
}
